# Muscle Growth Tracker — private beta

Version: 8.0.0-beta.3. Built separately from the current GitHub Pages app.

The beta implements workout generation, custom routine rotations, advanced set structures, history-based progression, equipment-aware gym scheduling, nutrition/meal scheduling, pantry and leftover allocation, shopping, an isolated Supabase synchronization client/backend, a notification service worker, and a server-side reminder job. All features remain free/unlocked.

## Start testing

1. Open the private beta address supplied with this build. Home is the default screen.
2. In History, import the JSON backup exported by your current app. Import merges records, keeps duplicate-date versions, and retains the original snapshot. The beta cannot read storage on the separate GitHub origin.
3. Review Settings → Your gyms and Gym schedules. A Fire Station recurrence starts October 4, 2026 and repeats every four days for one day; change the anchor if needed. Commercial inventory is an estimate, not a verified floor audit.
4. Use Program to preview an automatic block or save workouts as routines and build a custom rotation. Logged sessions are protected. The original 28-day program remains selectable.
5. Use Edit sets under an exercise for straight sets, ramping, top/back-off sets and drops. Set-by-set loads, reps, RIR and completion persist. Complete workout locks edits until confirmed unlock.
6. Nutrition → Targets & preferences sets daily/training/rest targets, household portions, diet, exclusions, preferred foods/snacks, and repeat spacing. Today’s Meals and Meal Schedule link to recipes and shopping. Record pantry stock and cooked leftovers; review package-size estimates before buying.
7. Optional cloud and push need the setup below. Local beta use works first.

## What is verified

Run `npm test` and `npm run check` with Node 22+. There are no frontend package dependencies or CDN scripts.

Tests cover migration and account isolation, preservation of edited gym inventories, aliases and anatomy, full equipment requirements, firefighter recurrence and date arithmetic, generator constraints, real set-load progression, recipe yield, exclusions, training/rest targets, leftovers and stock expiry, sync conflict preservation and retries, and UI render/action/form contracts.

The UI contract harness does not run a browser. Real browser rendering, Android/iOS installation, live Supabase authentication/RLS, cross-device sync, and closed-app push delivery remain acceptance tests. Browser automation was unavailable in the build environment; no visual or device verification is claimed.

## Connected cloud and reminders — current status

The existing Supabase project is connected. The isolated beta migration, owner-only RLS and revision-checked commit functions are installed. The original `user_app_data` table and its records remain unchanged. Eleven transactional two-identity database isolation checks passed, all synthetic writes were rolled back, and both Supabase advisors report no findings. The Auth API is reachable and requires email confirmation.

The separate `mgt-beta-send-reminders` Edge Function is ACTIVE. A once-per-minute cron job calls it using encrypted Vault authorization. Authorized calls returned HTTP 200; unauthorized calls returned HTTP 401. VAPID private material and the cron key remain in Vault; the function accesses them only through a service-only authorized RPC. Public RPC entrypoints use SECURITY INVOKER; privileged implementations are in the unexposed `mgt_beta_private` schema. The PWA automatically loads the public project/push configuration from `dist/config.json`.

### One account setting remains

The connected integration does not expose Auth URL configuration. Add this address to Supabase Authentication → URL Configuration → Redirect URLs, keeping the existing GitHub URL:

`https://muscle-growth-tracker-private-beta.crispcrown515.chatgpt.site/`

Settings link: https://supabase.com/dashboard/project/tdmwpcueqxtnqyonucam/auth/url-configuration

Then create/confirm a beta account in app Settings, import the original JSON backup in History, save reminder preferences and enable push on the phone. Real email sign-in, two-device reconciliation, installed-PWA/browser QA and actual closed-app delivery remain acceptance tests. The Supabase connection used here is project-management access; it does not create an app user account or import phone storage.

The original cloud table is read only when the user explicitly chooses “Import original cloud backup.” Active-app sync queues offline changes; arbitrary client JavaScript is not promised to run while a browser is closed. The cron job provides server-side reminders in the user’s time zone with a 15-minute delivery window. Delivery remains best effort; calendar export is independent.

For reinstallation, `supabase/migrations/001_beta.sql`, the reminder function and `supabase/schedule.sql` contain the schema/runtime setup. Configure Vault names `mgt_beta_vapid_public`, `mgt_beta_vapid_private`, `mgt_beta_vapid_subject`, `mgt_beta_cron_secret`, and `mgt_beta_function_url`; never commit their secret values. The runtime automatically receives Supabase’s server URL/service-role environment. Existing encrypted keys should be reused, not regenerated on every deployment.

Run `node scripts/api-live.mjs` for safe unauthenticated HTTP checks. `scripts/rls-live.sql` runs the transactional database isolation test. `scripts/cloud-smoke.mjs` is an optional real-account acceptance check requiring two dedicated test accounts; it has not been run because no real app users exist yet.

## Data and media

- Original local-storage keys `MGT28v6` and `MGT28v5` are read only for an offered migration. Beta records use `MGT_BETA_V8:<account-id-or-guest>`.
- Account workspaces remain separate on the device. Sign-out removes the local push subscription and preserves that account’s local backup.
- Imports are merge operations, not destructive restores. Original raw snapshots and conflicting versions are retained. Legacy loads are converted to the current unit convention; changing display units explicitly converts beta records.
- Three device recovery snapshots are retained before imports/destructive edits. Browser storage has a quota; export backups regularly. A failed storage write is shown as an error, not reported as saved.
- Machine/cable recommendations use history from the same gym. A checked working set and usable RIR are needed to earn a load increase. Warm-ups, drops and back-off sets cannot inflate progression.
- Recipe macros use built-in estimates or an explicit manual override. Raw/dry versus cooked quantities must match the product. Preferences filter recipe ingredients, but do not certify allergen cross-contact.
- All 162 recovered image originals are inventoried by identity and SHA-256; originals were not modified. 113 single-pose revisions were converted to full-size lossless WebP and pixel-verified. The beta has 35 canonical recovered Start/Finish pairs, 3 partials, plus archived guides/revisions. Many exercises still lack a matching photograph.
- Conversation approvals did not identify exact asset hashes. Recovered files are marked for approval-history verification; the build never invents approvals or photographs. The locked START → approval → FINISH generation workflow remains applicable.

See `docs/REQUIREMENTS.md`, `docs/EXERCISE_AUDIT.md`, `docs/MEDIA_AUDIT.md` and the test report for exact coverage and remaining acceptance work.

## Source layout

`dist/` is the buildless PWA. `supabase/` contains the isolated database and push backend. `tests/` holds Node tests. `scripts/` holds validation and the opt-in live smoke test. `.openai/hosting.json` identifies the separate private beta Site.

No changes have been pushed to `412doubleb/Muscle-Growth-Tracker`, and this build is not a replacement for its tested release.
